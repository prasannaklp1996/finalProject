package com.capgemini.capbook.service;

import java.util.List;

import com.capgemini.capbook.bean.Login;

public interface ILoginService {

	Boolean checkUser(Login login);
	
	List<Login> getAlllogins();
	

}
