package com.capgemini.capbook.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capbook.bean.Login;

@Repository("loginDao")
@Transactional
public interface ILoginDao extends JpaRepository<Login, String>{


    
    @Query("from Login  where mail=:email ")
    public Login findByUsername(@Param("email") String email);

    
}
