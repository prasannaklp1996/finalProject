package com.capgemini.capbook.service;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.data.repository.query.Param;

import com.capgemini.capbook.bean.ChangePassword;
import com.capgemini.capbook.bean.Email;
import com.capgemini.capbook.bean.Friend;
import com.capgemini.capbook.bean.Login;
import com.capgemini.capbook.bean.UserProfile;


public interface ICapBookService {

	List<Friend> saveFriend(Friend friend);
	
	List<Friend> getFriend();
	
	
	List<UserProfile> saveUser(UserProfile userprofile);
	
	List<Login> savelogin(Login login);
	
	List<ChangePassword> savepsswrd(ChangePassword changepsswd);
	
	List<Login> getLoginDetails();
	
	List<ChangePassword> getPsswrdDetails();
	
	List<UserProfile> getUserDetails();
	
	public List<Login> findByUsernameAndPassword(@Param("email") String email,@Param("password") String password );
	
	public String getPassword(@PathParam("email") String mail);
    
	List<Email> saveEmaildetails(Email email);
	
	public String getMail(Integer userId);
	
	public String getPsswdBymail(String mail);
	
	public List<ChangePassword> saveNewPwd(ChangePassword changePwd);
	
/*	public Integer saveNewPasswd(String mail,String Op, String Np);*/
	
	public Integer saveLgnPasswd(String Password,String email);
}
