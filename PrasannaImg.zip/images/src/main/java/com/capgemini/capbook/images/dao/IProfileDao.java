package com.capgemini.capbook.images.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capbook.images.bean.ImagesBean;

@Repository("profiledao")
@Transactional
public interface IProfileDao extends JpaRepository<ImagesBean, Integer> {

	
	@Query("select i.imageUrl from ImagesBean i where i.userId = :id and albumName = :location")
	List<String> getImage(@Param("id")Integer userId,@Param("location") String location);

	
	@Query("select i.imageUrl from ImagesBean i where i.userId = :id and albumName = 'profile' and i.imageId = :maxId")
	List<String> getProfilePic(@Param("id")Integer userId,@Param("maxId") Integer maxId);

	@Query("select max(i.imageId) from ImagesBean i where  i.userId = :id ")
	Integer getMaxId(@Param("id")Integer userId);


	
}
