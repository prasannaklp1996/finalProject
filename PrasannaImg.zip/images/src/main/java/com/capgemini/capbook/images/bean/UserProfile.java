package com.capgemini.capbook.images.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class UserProfile {
	
	@Id
	private Integer userId;
	private String userName;
	@OneToMany(mappedBy="userId",targetEntity=ImagesBean.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<ImagesBean> images=new ArrayList<ImagesBean>();
	public UserProfile() {
		
	}
	public UserProfile(Integer userId, String userName, List<ImagesBean> images) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.images = images;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public List<ImagesBean> getImages() {
		return images;
	}
	public void setImages(List<ImagesBean> images) {
		this.images = images;
	}
	@Override
	public String toString() {
		return "UserProfile [userId=" + userId + ", userName=" + userName + ", images=" + images + "]";
	}
	

}
